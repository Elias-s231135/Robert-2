#include "Enemy.h"

const void Enemy::Description()
{
	return void();
}

