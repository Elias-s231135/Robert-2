#pragma once
#include "Enemy.h"

class LeftHandedShopOwner : public Enemy
{
public:
	const void Description() override;
};