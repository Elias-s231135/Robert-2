#pragma once

class Enemy 
{
public:
	const virtual void Description();

protected:
	int health;
};