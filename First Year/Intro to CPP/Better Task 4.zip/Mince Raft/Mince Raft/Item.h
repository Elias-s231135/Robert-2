#pragma once

class Item
{
	virtual const void Description() = 0;
	virtual void Use() = 0;
};