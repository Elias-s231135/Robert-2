#include "CrabThatEatsMince.h"
#include <iostream>

using namespace std;

const void CrabThatEatsMince::Description()
{
    cout << "A crab that likes eating mince. Its mouth is scarred from trying to eat the pointy mince." << endl;
}
