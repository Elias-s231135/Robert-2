#include "LeftHandedShopOwner.h"
#include <iostream>

using namespace std;

const void LeftHandedShopOwner::Description()
{
    cout << "A shop owner who sells left-handed things. They appear to be primarily using their left hand." << endl;
}
