#pragma once
#include "Enemy.h"

class MincedMan : public Enemy
{
public:
	const void Description() override;
};