#include "MincedMan.h"
#include <iostream>

using namespace std;

const void MincedMan::Description()
{
    cout << "A humanoid figure who appears to be made entirely of mince that wriggles and writhes. It seems to be mumbling \"Man of mince, mince of man.\" over and over. \nChunks of mince occasionally fall out of it, until another piece slithers out of the cave floor to replace it. \nIt would be impossible to kill it in a way that would matter." << endl;
}
