#include "RightHandedShopOwner.h"
#include <iostream>

using namespace std;

const void RightHandedShopOwner::Description()
{
	cout << "A shop owner who sells items best wielded with a right hand. They appear to be primarily using their right hand." << endl;
}
