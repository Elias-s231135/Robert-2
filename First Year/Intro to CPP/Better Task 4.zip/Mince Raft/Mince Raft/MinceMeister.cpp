#include "MinceMeister.h"
#include <iostream>

using namespace std;

const void MinceMeister::Description()
{
    cout << "The extravagant baron of Mince Island, they seem keen to battle, but remain honourable. They wear a suit of armour that appears to be made of a sturdy yet lightweight material, likely some kind of mince" << endl;
}
