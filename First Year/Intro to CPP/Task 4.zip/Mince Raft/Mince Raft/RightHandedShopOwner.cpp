#include "RightHandedShopOwner.h"

const void RightHandedShopOwner::Description()
{
    return void();
}
