#include "Item.h"

const void Item::Description()
{
	return void();
}

void Item::Use()
{
}
