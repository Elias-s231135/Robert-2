#pragma once

class Item
{
	const void Description();
	void Use();
};