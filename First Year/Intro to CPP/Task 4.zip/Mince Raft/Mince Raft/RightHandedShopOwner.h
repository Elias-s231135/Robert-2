#pragma once
#include "Enemy.h"

class RightHandedShopOwner : public Enemy
{
public:
	const void Description() override;
};