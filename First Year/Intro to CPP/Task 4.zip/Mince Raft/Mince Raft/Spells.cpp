#include "Spells.h"
#include "StringTester.h"

Spell::Spell(String spellName, int damage)
{
}

void Spell::Cast()
{
}
