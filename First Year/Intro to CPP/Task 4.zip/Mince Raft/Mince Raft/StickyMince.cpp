#include "StickyMince.h"

StickyMince::StickyMince()
{
}

const void StickyMince::Description()
{
	return void();
}

void StickyMince::Use()
{
}
