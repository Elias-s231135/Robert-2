#include "PointyMince.h"

PointyMince::PointyMince()
{
}

const void PointyMince::Description()
{
	return void();
}

void PointyMince::Use()
{
}
