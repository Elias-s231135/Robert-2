#include "CrabThatEatsMince.h"

const void CrabThatEatsMince::Description()
{
    return void();
}
