#include "LeftHandedShopOwner.h"

const void LeftHandedShopOwner::Description()
{
    return void();
}
