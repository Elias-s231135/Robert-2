#include "LeftHandedMince.h"

LeftHandedMince::LeftHandedMince()
{
}

const void LeftHandedMince::Description()
{
	return void();
}

void LeftHandedMince::Use()
{
}
