#pragma once
#include "Item.h"

//class Enemy;
#include "Enemy.h"

class CrabThatEatsMince : public Enemy
{
public:
	//const void Description();
	const void Description() override;
};