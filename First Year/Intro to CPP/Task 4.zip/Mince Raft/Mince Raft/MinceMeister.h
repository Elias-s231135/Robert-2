#pragma once
#include "Enemy.h"

class MinceMeister : public Enemy
{
public:
	const void Description() override;
};