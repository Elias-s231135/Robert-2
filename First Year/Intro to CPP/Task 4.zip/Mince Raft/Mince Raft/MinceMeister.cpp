#include "MinceMeister.h"

const void MinceMeister::Description()
{
    return void();
}
