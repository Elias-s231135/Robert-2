#include "RightHandedMince.h"

RightHandedMince::RightHandedMince()
{
}

const void RightHandedMince::Description()
{
    return void();
}

void RightHandedMince::Use()
{
}
