#include "MincedMan.h"

const void MincedMan::Description()
{
    return void();
}
