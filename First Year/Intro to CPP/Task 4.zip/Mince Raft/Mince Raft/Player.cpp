#include "Player.h"
#include "StringTester.h"

Player::Player()
{
}

Player::~Player()
{
}

bool Player::FindSpell(String spell)
{
	return false;
}
