#include "SturdyMince.h"

SturdyMince::SturdyMince()
{
}

const void SturdyMince::Description()
{
	return void();
}

void SturdyMince::Use()
{
}
